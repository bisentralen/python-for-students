import pandas as pd
import matplotlib.pyplot as plt
import fundlib



def readfile_and_makeobjects(filename):
    # Read CSV file into a Pandas DataFrame
    df = pd.read_csv(filename) # A Pandas DataFrame
    stocks = {}     # An empty dictionary
    for index, row in df.iterrows():
        # Loop over DataFrame, make a Stock object for each line, and save it in a dict
        stocks[row['ticker']] = fundlib.Stock(row['ticker'], row['company_name'], row['price'])
    return stocks



def update_stock_prices(stocks):
	"""Takes a dict of Stock objects, and calls their update_price()"""
	for ticker in stocks:
		stocks[ticker].update_price()



# Make a dict of stock objects
stocks = readfile_and_makeobjects("data_stocks.csv")

# Make a fund
my_fund = fundlib.Fund("More is More")

# Buy stocks
my_fund.buy_stock(stocks['sur'], 900)
my_fund.buy_stock(stocks['nid'], 1300)
my_fund.buy_stock(stocks['nys'], 1100)

# Print fund data
print(my_fund)

update_stock_prices(stocks)

# Print fund data
print(my_fund)

# Buy more
my_fund.buy_stock(stocks['nid'], 400)
my_fund.buy_stock(stocks['alu'], 700)

update_stock_prices(stocks)

# Print fund data
print(my_fund)




#####################################################
# Plot a time series of the total value of the fund

# Make a list of ascending integers to represent time
x = [i for i in range(0,1000)]

# Make an empty list to store fund values for each point in time
y = []

# For each time, store the value and update prices
for time in x:
	y.append(my_fund.get_value()['total'])
	update_stock_prices(stocks)


# Make the value plot
plt.plot(x, y, label="Total Value")
# Descriptive elements
plt.xlabel("Time")
plt.ylabel("Value")
plt.title("Fund Value Time Series")
plt.legend()  # Identifies each line in the plot
# Save the plot
plt.savefig("chart.png")



