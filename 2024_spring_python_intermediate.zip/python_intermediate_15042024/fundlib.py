from random import uniform
import pandas as pd


class Fund:
	""" Class for an equity fund. """

	def __init__(self, fund_name, start_cash=100_000.0):
		"""Constructor - initializes object."""
		self.name = fund_name
		self.cash = start_cash
		self.portfolio = {}  # Dict with ticker as key, and a another dict {stock, price_paid, volume} as value


	def __str__(self):
		"""Overriding the built-in string representation of a fund object. Returns key fund data as a formatted string."""
		# Fund value
		cash, assets, total = self.get_value().values()
		valuestring = f"Cash value: {cash:_.2f}\nAssets value: {assets:_.2f}\nTotal value: {total:_.2f}\n"
		# Portfolio
		portfoliostring = f"\n{'Tick':<5}{'Name':<28}{'P Now':<7}{'P Paid':<7}{'Volume':<6}\n"
		for ticker, entry in self.portfolio.items():
			portfoliostring += f"{ticker:<5}{entry['stock'].name:<28}{entry['stock'].price:<7}{entry['price_paid']:<7}{entry['volume']:<6}\n"
		border = f"\n{'-'*60}\n"
		return valuestring + portfoliostring + border


	def buy_stock(self, stock, volume):
		"""Takes a stock object and volume."""
		ticker, _, price = stock.ticker, stock.name, stock.price
		# If ticker exists in portfolio, average the price and add the volume
		if ticker in self.portfolio:
			p0 = self.portfolio[ticker]['price_paid']
			v0 = self.portfolio[ticker]['volume']
			price_avg = (p0*v0 + price*volume) / (v0 + volume)  # Weighted average of previous buy and this
			price_avg = round(price, 2) # Rounding off to two digits
			# Update paid_price and volume in portfolio
			self.portfolio[ticker]['price_paid'] = price_avg
			self.portfolio[ticker]['volume'] = v0 + volume
			self.cash -= volume*price
		else:
			# Make a new entry in the portfolio
			self.portfolio[ticker] = {'stock':stock, 'price_paid':price, 'volume':volume}
			# Update cash holding
			self.cash -= volume*price


	def get_value(self):
		# Assets value
		assets_value = 0
		for ticker, entry in self.portfolio.items():
			assets_value += entry['stock'].price * entry['volume']
		total_value = self.cash + assets_value
		return {'cash':self.cash, 'assets':assets_value, 'total':total_value}





class Stock:
	"""Class describing stocks."""
	def __init__(self, ticker, name, price):
		self.ticker = ticker
		self.name = name
		self.price = price

	def update_price(self):
		"""Creates new stockprice randomly."""
		self.price *= 1 + uniform(-0.05,0.05)
		self.price = round(self.price, 2)

