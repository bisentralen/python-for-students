from random import uniform

# a function
def raise5(n):
    n2 = n * 1.05
    return n2

p = 12.50
p1 = raise5(p)
print(f"{p1 = }")

# also a function
def update_price(price): # REMOVE PARAMETER
    #global price
    price *= 1 + uniform(-0.05,0.05)
    price = round(price, 2)


price = 100
update_price(price)      # REMOVE PARAMETER
print(f"{price = }")



# EXERCISE:
# Write a function buy_stock, that takes two numbers as parameters: price and volume
# The function should return the value, price * volume
# Test the function

# ANSWER:
def buy_stock(price, volume):
    value = price * volume
    return value

print(buy_stock(23.3, 1000))


